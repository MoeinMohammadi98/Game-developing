using System.Collections;
using UnityEngine;
using UnityEngine.InputSystem;

public class Controller : MonoBehaviour
{
    public float speed;
    public GameObject gun;
    public GameObject Bullet;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.D))
        {
            transform.position += new Vector3(1, 0, 0) * speed * Time.deltaTime;
            GetComponent<Animator>().SetInteger("Mode", 1);
        }
        else if (Input.GetKey(KeyCode.A))
        {
            transform.position += new Vector3(-1, 0, 0) * speed * Time.deltaTime;
            GetComponent<Animator>().SetInteger("Mode", 1);
        }
        else if (Input.GetKey(KeyCode.Space))
        {
            Instantiate(Bullet, gun.transform.position, Quaternion.identity);
        }
        else
        {
            GetComponent<Animator>().SetInteger("Mode", 0);
        }

        
    }
}
